npm install -g aiot-vue-cli
npm run build